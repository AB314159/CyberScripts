sudo chown root:root /etc/samba/smb.conf
sudo chmod 644 /etc/samba/smb.conf