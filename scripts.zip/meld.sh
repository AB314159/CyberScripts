sudo apt install meld
sudo meld backups current
read -p "Press Enter to continue" </dev/tty
sudo meld Desktop/plain_backup/boot /boot
read -p "Press Enter to continue" </dev/tty
sudo meld Desktop/plain_backup/etc /etc
read -p "Press Enter to continue" </dev/tty
sudo meld Desktop/plain_backup/lib /lib
read -p "Press Enter to continue" </dev/tty
sudo meld Desktop/plain_backup/root /root
read -p "Press Enter to continue" </dev/tty
sudo meld Desktop/plain_backup/run /run
read -p "Press Enter to continue" </dev/tty
