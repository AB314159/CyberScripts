echo "Checking for netrc files"
sudo find /root /home -iname “.netrc” 2> /dev/null
echo "================================"
echo "Changing VSFTPD config files"
echo "anonymous_enable=NO" >> /etc/vsftpd.conf
echo "chroot_local_user=YES" >> /etc/vsftpd.conf
echo "xferlog_enable=YES" >> /etc/vsftpd.conf
echo "xferlog_std_format=NO" >> /etc/vsftpd.conf
echo "log_ftp_protocol=YES" >> /etc/vsftpd.conf
echo "force_dot_files=NO" >> /etc/vsftpd.conf
echo "write_enable=YES" >> /etc/vsftpd.conf
echo "ssl_enable=YES" >> /etc/vsftpd.conf
string="chown_username=root"
sudo sed -i '/$string/d' /etc/vsftpd.conf
string="ascii_download_enable=YES"
sudo sed -i '/$string/d' /etc/vsftpd.conf
sudo service vsftpd restart
sudo chmod 644 /etc/vsftpd.conf
sudo chown root:root /etc/vsftpd.conf
sudo chgrp root /etc/vsftpd.conf
echo "vsftpd: ALL" >> /etc/hosts.allow
iptables -I INPUT -p tcp --dport 64000:65535 -j ACCEPT
ufw allow 21/tcp