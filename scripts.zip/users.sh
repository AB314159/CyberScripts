#!/bin/bash

# Get the username of the user running the script
current_user=$(whoami)

# Prompt for authorized users
echo -n "Authorized Users (space-separated): "
read -r users

# Loop through provided authorized users
for user in $users; do
    # Skip the current user
    if [ "$user" == "$current_user" ]; then
        echo "Skipping password change for the current user: $current_user"
        continue
    fi

    # Check if the user exists on the system
    if getent passwd "$user" > /dev/null 2>&1; then
        echo "$user already exists. Changing password."
        echo "$user:CyberPatriot1!" | sudo chpasswd
    else
        echo "$user does not exist. Adding user."
        sudo useradd -m -s /bin/bash "$user"
        echo "$user:CyberPatriot1!" | sudo chpasswd
    fi
done

# Declare the uids array
declare -A uids

# Loop through system users to identify unauthorized users and handle duplicate UIDs
while IFS=: read -r name password uid gid gecos home shell; do
    if [ "$uid" -ge 1000 ] && [ "$uid" -lt 60000 ]; then

        if [ "$name" == "$current_user" ]; then
            echo "Skipping deletion for the current user: $current_user"
            continue
        fi

        if [ "$home" != "/home/$name" ]; then
            echo "============================================"
            echo "The home directory of user $name is $home"
            echo "============================================"
        fi

        if echo "$users" | grep -qw "$name"; then
            if [ "${uids[$uid]}" ]; then
                echo "=========================================="
                echo "User $name has a duplicate UID ($uid)."
                echo "=========================================="
            else
                uids[$uid]=1
                echo "$name is an authorized user. Password updated."
            fi

            if [ "$shell" = "/usr/sbin/nologin" ] || [ "$shell" = "/bin/false" ]; then
                echo "===================================="
                echo "$name has shell of $shell"
                echo "===================================="
            fi
        else
            echo "$name is an unauthorized user. Deleting."
            sudo deluser --remove-home "$name"
        fi
    fi

    if [ "$uid" -eq 0 ] && [ "$name" != "root" ]; then
        echo "Going to delete root imposter $name now. If needed, prepare for this using other terminal before proceeding"
        echo -n "Type y if continue or n if not: "
        read -r y_or_n < /dev/tty
        if [ "$y_or_n" == "y" ]; then
            echo "==========================="
            echo "There is a root imposter $name!"
            echo "Removing root imposter."
            sudo sed -i "/^$name:/d" /etc/passwd
            echo "==========================="
        fi
    fi
done < <(getent passwd)

echo "==========================="
echo "Checking for duplicate user IDs"
awk -F ":" 'list[$3]++{print $1, $3}' /etc/passwd
echo "==========================="
echo "Checking for blank passwords in shadow file"
sudo awk -F: '!$2 {print $1}' /etc/shadow
echo "==========================="
echo "Setting secure password for root"
echo "root:CyberPatriot1!" | sudo chpasswd
echo "Locking root account"
sudo passwd -l root
echo "==========================="
cat /etc/passwd
echo "Inspect /etc/passwd and delete bad password. ABOVE"
echo "==========================="
echo "Do grpck"
sudo grpck
read -p "Press Enter to continue" </dev/tty
echo "==========================="
echo "Do pwck"
sudo pwck
read -p "Press Enter to continue" </dev/tty
echo "==========================="
echo "Need to add chage -M 90 -W 14 -m 7 for all users in the script"
read -p "Press Enter to continue" </dev/tty
echo "==========================="
echo "Check no local users have ID less than 1000"
cat /etc/passwd
read -p "Press Enter to continue" </dev/tty
echo "==========================="
echo "Check no system users have no valid login shell"
cat /etc/passwd
read -p "Press Enter to continue" </dev/tty
echo "==========================="
echo "Check folder size for all users to make sure no abnormal activity"
sudo du -sh /home/*
read -p "Press Enter to continue" </dev/tty
echo "==========================="
