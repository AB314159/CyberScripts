lsb_release -a
hostnamectl
