ifconfig -a
nmcli
nmcli device show
ip link show
ethtool eth0
ip neighbor show
arp
ip address show
sudo apt install -y traceroute
traceroute www.google.com
ip route show
nslookup www.google.com
dig google.com
netstat -anpl
ss -tunlp4
